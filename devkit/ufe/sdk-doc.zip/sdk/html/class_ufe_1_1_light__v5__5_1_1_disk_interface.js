var class_ufe_1_1_light__v5__5_1_1_disk_interface =
[
    [ "~DiskInterface", "class_ufe_1_1_light__v5__5_1_1_disk_interface.html#a4521dc1c857ba2c0d171a7a68c22d197", null ],
    [ "volumeProps", "class_ufe_1_1_light__v5__5_1_1_disk_interface.html#ac6b03de98a0e34841ce8cc56426d7320", null ],
    [ "volumeProps", "class_ufe_1_1_light__v5__5_1_1_disk_interface.html#a9402b878faa4da724dad6e35d6f525a7", null ],
    [ "volumePropsCmd", "class_ufe_1_1_light__v5__5_1_1_disk_interface.html#ac7368f134ac8e9ae79f95a5f005b22fe", null ]
];