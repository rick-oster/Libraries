var dir_130f4d2fd384b187ef38323b8209e734 =
[
    [ "VerFormat.h", "_ver_format_8h.html", "_ver_format_8h" ],
    [ "VerInfo.h", "_ver_info_8h.html", "_ver_info_8h" ]
];