var class_ufe_1_1_selection_replaced =
[
    [ "SelectionReplaced", "class_ufe_1_1_selection_replaced.html#a290665a5e47a42733b0e2d79eba86624", null ],
    [ "SelectionReplaced", "class_ufe_1_1_selection_replaced.html#a90152156b3371995fac190b7d152c0e3", null ],
    [ "~SelectionReplaced", "class_ufe_1_1_selection_replaced.html#a991a10f12922fbb4737c6155f586cb51", null ],
    [ "previousSelection", "class_ufe_1_1_selection_replaced.html#acf1056a1deef177a5fd400057b4a72ec", null ],
    [ "fPreviousSelection", "class_ufe_1_1_selection_replaced.html#add5b5f01e051e8b230d49b248dd3f416", null ]
];