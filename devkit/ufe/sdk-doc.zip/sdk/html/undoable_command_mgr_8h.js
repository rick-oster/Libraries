var undoable_command_mgr_8h =
[
    [ "Ufe::UndoableCommandMgr", "class_ufe_1_1_undoable_command_mgr.html", "class_ufe_1_1_undoable_command_mgr" ],
    [ "Ufe::UndoableCommandGuard", "class_ufe_1_1_undoable_command_guard.html", "class_ufe_1_1_undoable_command_guard" ]
];