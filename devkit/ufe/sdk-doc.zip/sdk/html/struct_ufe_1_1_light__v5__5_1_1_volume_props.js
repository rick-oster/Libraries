var struct_ufe_1_1_light__v5__5_1_1_volume_props =
[
    [ "length", "struct_ufe_1_1_light__v5__5_1_1_volume_props.html#a57b3c058c9378ae5f9ccb2332d6ec45e", null ],
    [ "radius", "struct_ufe_1_1_light__v5__5_1_1_volume_props.html#a1153febf238c08f231af7586ca2c8c1f", null ]
];