var selection_notification_8h =
[
    [ "Ufe::SelectionChanged", "class_ufe_1_1_selection_changed.html", "class_ufe_1_1_selection_changed" ],
    [ "Ufe::SelectionItemAppended", "class_ufe_1_1_selection_item_appended.html", "class_ufe_1_1_selection_item_appended" ],
    [ "Ufe::SelectionItemRemoved", "class_ufe_1_1_selection_item_removed.html", "class_ufe_1_1_selection_item_removed" ],
    [ "Ufe::SelectionItemInserted", "class_ufe_1_1_selection_item_inserted.html", "class_ufe_1_1_selection_item_inserted" ],
    [ "Ufe::SelectionCleared", "class_ufe_1_1_selection_cleared.html", "class_ufe_1_1_selection_cleared" ],
    [ "Ufe::SelectionReplaced", "class_ufe_1_1_selection_replaced.html", "class_ufe_1_1_selection_replaced" ],
    [ "Ufe::SelectionCompositeNotification", "class_ufe_1_1_selection_composite_notification.html", "class_ufe_1_1_selection_composite_notification" ],
    [ "Ufe::SelectionCompositeNotification::Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html", "struct_ufe_1_1_selection_composite_notification_1_1_op" ]
];