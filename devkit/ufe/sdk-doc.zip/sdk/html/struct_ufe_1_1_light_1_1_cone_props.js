var struct_ufe_1_1_light_1_1_cone_props =
[
    [ "angle", "struct_ufe_1_1_light_1_1_cone_props.html#a2d027c5ff13c511c3f8ba7545c51bace", null ],
    [ "focus", "struct_ufe_1_1_light_1_1_cone_props.html#a9d7eb9e554c826fd348cf7f11831df5a", null ],
    [ "softness", "struct_ufe_1_1_light_1_1_cone_props.html#a86a269bcc25a529422847c17d22eb39f", null ]
];