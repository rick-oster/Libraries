var global_selection_8h =
[
    [ "Ptr", "global_selection_8h.html#abcb6bd477b0d44a6ebf8b5f1e3573268", null ],
    [ "get", "global_selection_8h.html#a6e97c38c54dd11053860fc3f51b012be", null ],
    [ "initializeInstance", "global_selection_8h.html#a634fa9d70d5cf0de940542075a4a4ecf", null ]
];