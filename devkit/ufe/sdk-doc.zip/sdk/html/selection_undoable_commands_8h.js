var selection_undoable_commands_8h =
[
    [ "Ufe::SelectionAppendItem", "class_ufe_1_1_selection_append_item.html", "class_ufe_1_1_selection_append_item" ],
    [ "Ufe::SelectionRemoveItem", "class_ufe_1_1_selection_remove_item.html", "class_ufe_1_1_selection_remove_item" ],
    [ "Ufe::SelectionClear", "class_ufe_1_1_selection_clear.html", "class_ufe_1_1_selection_clear" ],
    [ "Ufe::SelectionReplaceWith", "class_ufe_1_1_selection_replace_with.html", "class_ufe_1_1_selection_replace_with" ]
];