var class_ufe_1_1_light__v5__5 =
[
    [ "CylinderInterface", "class_ufe_1_1_light__v5__5_1_1_cylinder_interface.html", "class_ufe_1_1_light__v5__5_1_1_cylinder_interface" ],
    [ "DiskInterface", "class_ufe_1_1_light__v5__5_1_1_disk_interface.html", "class_ufe_1_1_light__v5__5_1_1_disk_interface" ],
    [ "DomeInterface", "class_ufe_1_1_light__v5__5_1_1_dome_interface.html", "class_ufe_1_1_light__v5__5_1_1_dome_interface" ],
    [ "VolumeProps", "struct_ufe_1_1_light__v5__5_1_1_volume_props.html", "struct_ufe_1_1_light__v5__5_1_1_volume_props" ],
    [ "Ptr", "class_ufe_1_1_light__v5__5.html#af56b0cb7a2c8852157f853135db84395", null ],
    [ "VolumePropsUndoableCommand", "class_ufe_1_1_light__v5__5.html#abf7fb62354c613b78ca99a04f5106118", null ],
    [ "Light_v5_5", "class_ufe_1_1_light__v5__5.html#ae197ded32d4dccca9b451c6eb4a1858a", null ],
    [ "Light_v5_5", "class_ufe_1_1_light__v5__5.html#aaf191b81bbdc7a09e6ab2149166bcbe6", null ],
    [ "~Light_v5_5", "class_ufe_1_1_light__v5__5.html#ad0cafc20a8b4de50df8ea7f93760f67a", null ],
    [ "cylinderInterface", "class_ufe_1_1_light__v5__5.html#aea1b714f49cadcd7f9f33b637bec3ca7", null ],
    [ "cylinderInterfaceImpl", "class_ufe_1_1_light__v5__5.html#a7b8555689dac81442a1f68803ce99908", null ],
    [ "diskInterface", "class_ufe_1_1_light__v5__5.html#a0d127b431115679f10d9d1cf7b35b5e2", null ],
    [ "diskInterfaceImpl", "class_ufe_1_1_light__v5__5.html#afcf45620face3c78cbbcbe75b70c4ab7", null ],
    [ "domeInterface", "class_ufe_1_1_light__v5__5.html#ac4a7319db795110c7d060e67b398bd41", null ],
    [ "domeInterfaceImpl", "class_ufe_1_1_light__v5__5.html#adbc1eab8fc5ef31316b8c8c20ece661b", null ],
    [ "light", "class_ufe_1_1_light__v5__5.html#a802d79a972dd575d76c86d802ba9cb69", null ]
];