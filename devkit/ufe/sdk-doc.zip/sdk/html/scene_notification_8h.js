var scene_notification_8h =
[
    [ "Ufe::SceneChanged", "class_ufe_1_1_scene_changed.html", "class_ufe_1_1_scene_changed" ],
    [ "Ufe::ObjectAdd", "class_ufe_1_1_object_add.html", "class_ufe_1_1_object_add" ],
    [ "Ufe::ObjectDelete", "class_ufe_1_1_object_delete.html", "class_ufe_1_1_object_delete" ],
    [ "Ufe::ObjectPostDelete", "class_ufe_1_1_object_post_delete.html", "class_ufe_1_1_object_post_delete" ],
    [ "Ufe::ObjectPreDelete", "class_ufe_1_1_object_pre_delete.html", "class_ufe_1_1_object_pre_delete" ],
    [ "Ufe::ObjectDestroyed", "class_ufe_1_1_object_destroyed.html", "class_ufe_1_1_object_destroyed" ],
    [ "Ufe::ObjectPathChange", "class_ufe_1_1_object_path_change.html", "class_ufe_1_1_object_path_change" ],
    [ "Ufe::ObjectRename", "class_ufe_1_1_object_rename.html", "class_ufe_1_1_object_rename" ],
    [ "Ufe::ObjectReparent", "class_ufe_1_1_object_reparent.html", "class_ufe_1_1_object_reparent" ],
    [ "Ufe::ObjectPathAdd", "class_ufe_1_1_object_path_add.html", "class_ufe_1_1_object_path_add" ],
    [ "Ufe::ObjectPathRemove", "class_ufe_1_1_object_path_remove.html", "class_ufe_1_1_object_path_remove" ],
    [ "Ufe::SubtreeInvalidate", "class_ufe_1_1_subtree_invalidate.html", "class_ufe_1_1_subtree_invalidate" ],
    [ "Ufe::SceneCompositeNotification", "class_ufe_1_1_scene_composite_notification.html", "class_ufe_1_1_scene_composite_notification" ],
    [ "Ufe::SceneCompositeNotification::Op", "struct_ufe_1_1_scene_composite_notification_1_1_op.html", "struct_ufe_1_1_scene_composite_notification_1_1_op" ]
];