var searchData=
[
  ['trie_3c_20t_20_3e_0',['Trie&lt; T &gt;',['../class_ufe_1_1_trie_node.html#a72f7c3128836709b1663c5f2197387c7',1,'Ufe::TrieNode']]]
];
