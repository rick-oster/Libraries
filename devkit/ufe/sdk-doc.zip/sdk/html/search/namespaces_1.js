var searchData=
[
  ['namedselection_0',['NamedSelection',['../namespace_named_selection.html',1,'']]]
];
