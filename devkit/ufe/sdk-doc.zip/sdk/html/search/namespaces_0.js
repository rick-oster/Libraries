var searchData=
[
  ['globalselection_0',['GlobalSelection',['../namespace_global_selection.html',1,'']]]
];
