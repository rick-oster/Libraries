var searchData=
[
  ['type_0',['Type',['../class_ufe_1_1_light.html#a51abe68a80faf447f08f1cb2dc3a9d0a',1,'Ufe::Light::Type()'],['../class_ufe_1_1_edit_transform3d_hint.html#acd51f4d7929248321300093aec92a3ab',1,'Ufe::EditTransform3dHint::Type()']]]
];
