var searchData=
[
  ['haschildren_0',['HasChildren',['../struct_ufe_1_1_context_item.html#a292e0ae9d6c1d779bfe2fe76bbd1b678',1,'Ufe::ContextItem']]]
];
