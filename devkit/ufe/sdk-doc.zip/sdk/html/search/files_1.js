var searchData=
[
  ['baseundoablecommands_2eh_0',['baseUndoableCommands.h',['../base_undoable_commands_8h.html',1,'']]],
  ['batchcompositecommand_2eh_1',['batchCompositeCommand.h',['../batch_composite_command_8h.html',1,'']]],
  ['batchopshandler_2eh_2',['batchOpsHandler.h',['../batch_ops_handler_8h.html',1,'']]]
];
