var searchData=
[
  ['globalselection_2eh_0',['globalSelection.h',['../global_selection_8h.html',1,'']]]
];
