var searchData=
[
  ['horizontalapertureoffsetundoablecommand_0',['HorizontalApertureOffsetUndoableCommand',['../namespace_ufe.html#abc689b21bcb6898874fcc3d81b252b48',1,'Ufe']]],
  ['horizontalapertureundoablecommand_1',['HorizontalApertureUndoableCommand',['../namespace_ufe.html#a7625b42c2c4ba95090b2f67b1c1e0f7f',1,'Ufe']]]
];
