var searchData=
[
  ['observers_0',['Observers',['../class_ufe_1_1_subject.html#ac1782eedd9615a2e4344dca83b734017',1,'Ufe::Subject']]],
  ['ops_1',['Ops',['../class_ufe_1_1_scene_composite_notification.html#a2f0d5e2b716aa7afa193cc07db15b711',1,'Ufe::SceneCompositeNotification::Ops()'],['../class_ufe_1_1_selection_composite_notification.html#ac6f7259751353ea72cf0f02021f2a401',1,'Ufe::SelectionCompositeNotification::Ops()']]]
];
