var searchData=
[
  ['undoablecommandguard_0',['UndoableCommandGuard',['../class_ufe_1_1_undoable_command_mgr.html#a7bfd5f143ca61053e6ddd4ab67273cbd',1,'Ufe::UndoableCommandMgr']]]
];
