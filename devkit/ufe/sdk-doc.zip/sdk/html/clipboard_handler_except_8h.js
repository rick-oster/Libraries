var clipboard_handler_except_8h =
[
    [ "Ufe::EmptyClipboardOperation", "class_ufe_1_1_empty_clipboard_operation.html", "class_ufe_1_1_empty_clipboard_operation" ],
    [ "Ufe::NoClipboardHandler", "class_ufe_1_1_no_clipboard_handler.html", "class_ufe_1_1_no_clipboard_handler" ],
    [ "Ufe::EmptyClipboardSelection", "class_ufe_1_1_empty_clipboard_selection.html", "class_ufe_1_1_empty_clipboard_selection" ]
];