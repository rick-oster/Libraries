var struct_ufe_1_1_paste_clipboard_command_1_1_paste_info =
[
    [ "failedPastes", "struct_ufe_1_1_paste_clipboard_command_1_1_paste_info.html#a2dfa709db523c6d8d5da50582338d6fb", null ],
    [ "pasteTarget", "struct_ufe_1_1_paste_clipboard_command_1_1_paste_info.html#a477bc063a1a3a8c849277c934fbd1876", null ],
    [ "successfulPastes", "struct_ufe_1_1_paste_clipboard_command_1_1_paste_info.html#a8e68e0af04f8289d871b72ead27972a6", null ]
];