var class_ufe_1_1_version_info =
[
    [ "getBuildDate", "class_ufe_1_1_version_info.html#af7443a90a5490fb11b1dc9440c053124", null ],
    [ "getBuildNumber", "class_ufe_1_1_version_info.html#a7cb2abd0579cb1565210d5dcb895fb1c", null ],
    [ "getGitBranch", "class_ufe_1_1_version_info.html#a92d618d3edf81ef8a02251cd7a0e7266", null ],
    [ "getGitCommit", "class_ufe_1_1_version_info.html#a247e61d08c732ea96476d2ebc707fb40", null ],
    [ "getMajorVersion", "class_ufe_1_1_version_info.html#a46e634f29053bc54710c2b1b7687c086", null ],
    [ "getMinorVersion", "class_ufe_1_1_version_info.html#ae5b6882966a1c77b4aca10bc727c7b67", null ],
    [ "getPatchLevel", "class_ufe_1_1_version_info.html#a5057b5525efb70cf2650a1ccf5214882", null ]
];