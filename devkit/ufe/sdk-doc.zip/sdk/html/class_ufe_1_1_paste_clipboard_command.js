var class_ufe_1_1_paste_clipboard_command =
[
    [ "PasteInfo", "struct_ufe_1_1_paste_clipboard_command_1_1_paste_info.html", "struct_ufe_1_1_paste_clipboard_command_1_1_paste_info" ],
    [ "Ptr", "class_ufe_1_1_paste_clipboard_command.html#ac09c6ec3f38464430c409c724a4fbbf4", null ],
    [ "PasteClipboardCommand", "class_ufe_1_1_paste_clipboard_command.html#a5b020d85ce97e6ee374ac6ee75fd8e82", null ],
    [ "~PasteClipboardCommand", "class_ufe_1_1_paste_clipboard_command.html#a959ba3053739218c604bb9be1ee7ba65", null ],
    [ "PasteClipboardCommand", "class_ufe_1_1_paste_clipboard_command.html#a0516e55220290ee30c11cb359fcdfe4d", null ],
    [ "PasteClipboardCommand", "class_ufe_1_1_paste_clipboard_command.html#aef574a89cf2485801547cd70ef9da6da", null ],
    [ "getPasteInfos", "class_ufe_1_1_paste_clipboard_command.html#ac52e667b0a58616cc2645bdcc1cbf698", null ],
    [ "operator=", "class_ufe_1_1_paste_clipboard_command.html#a40546ec1a81c507e87ed56356ce6faaa", null ],
    [ "operator=", "class_ufe_1_1_paste_clipboard_command.html#af26d4b84fc377560fbeaa29144ab031f", null ],
    [ "targetItems", "class_ufe_1_1_paste_clipboard_command.html#a72445e74d11765441f7168bc20fc19be", null ]
];