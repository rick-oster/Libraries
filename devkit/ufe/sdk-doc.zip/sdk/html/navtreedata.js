/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "ufe", "index.html", [
    [ "UFE API Documentation", "index.html", [
      [ "Introduction to UFE", "index.html#autotoc_md0", [
        [ "UFE Usage", "index.html#autotoc_md1", null ],
        [ "UFE Usefulness", "index.html#autotoc_md2", null ],
        [ "Advantages of working with UFE", "index.html#autotoc_md3", [
          [ "Development schedule flexibility", "index.html#autotoc_md4", null ],
          [ "Component swap", "index.html#autotoc_md5", null ],
          [ "Interoperability in data model", "index.html#autotoc_md6", null ],
          [ "Simulation engines & renderers", "index.html#autotoc_md7", null ]
        ] ]
      ] ]
    ] ],
    [ "UFE Concepts and Architecture", "ufe_philosophy.html", [
      [ "Fundamental Concepts", "ufe_philosophy.html#fundamentals", null ],
      [ "Architecture", "ufe_philosophy.html#architecture", [
        [ "Object Versus Data Model Object Lifescope", "ufe_philosophy.html#UFE", null ]
      ] ],
      [ "Implementation", "ufe_philosophy.html#implementation", null ],
      [ "Runtime Interfaces", "ufe_philosophy.html#runTimeInterfaces", null ],
      [ "Notifications", "ufe_philosophy.html#notifications", null ],
      [ "Selection", "ufe_philosophy.html#selection", null ],
      [ "Global Application Services", "ufe_philosophy.html#globalServices", [
        [ "Scene", "ufe_philosophy.html#scene", null ],
        [ "Global Selection", "ufe_philosophy.html#globalSelection", null ],
        [ "Path Strings", "ufe_philosophy.html#pathString", null ],
        [ "Named Selection", "ufe_philosophy.html#namedSelection", null ]
      ] ],
      [ "Undo / Redo", "ufe_philosophy.html#undoRedo", null ],
      [ "Versioning", "ufe_philosophy.html#versioning", null ]
    ] ],
    [ "code wrapper to control the execution of composite commands", "ufe_code_wrapper.html", [
      [ "Introduction", "ufe_code_wrapper.html#autotoc_md8", [
        [ "Code Wrapper Classes", "ufe_code_wrapper.html#autotoc_md9", null ],
        [ "Composite Command Wrapping", "ufe_code_wrapper.html#autotoc_md10", null ],
        [ "Testing", "ufe_code_wrapper.html#autotoc_md11", null ]
      ] ]
    ] ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_cfg_compiler_macros_8h.html",
"class_ufe_1_1_attribute_connection_changed.html",
"class_ufe_1_1_batch_composite_command.html#ab0a4888633d8db04c9eefd7122630844",
"class_ufe_1_1_code_wrapper_handler.html#a8328afcab8c9a84bc6db3d2206348ee8",
"class_ufe_1_1_hierarchy.html#a3dd37eb944cad0ffc663ea1d2df94849",
"class_ufe_1_1_light.html#aeb6aed7ef869429e269512bbb3ab384e",
"class_ufe_1_1_object3d.html#a751360fff9a951bd76eb18b9e1293b0a",
"class_ufe_1_1_observer.html#a6f4ac07f8f3410ebf927d28feebd5a39",
"class_ufe_1_1_path_subject.html#aad0036f4d378ccc40ff40cb3526828ed",
"class_ufe_1_1_scene_item.html#a7ff25c4176cc0354825703e49f71fbb9",
"class_ufe_1_1_selection_clear.html#ad3d25a2ca0fee3bf3c391aae573e80d9",
"class_ufe_1_1_transform3d.html#a07aea459d5dd701eae831a52dd97cb6d",
"class_ufe_1_1_trie_node.html#a5c3b389d0f37fa0121deaf467293a04c",
"class_ufe_1_1_version_info.html#a92d618d3edf81ef8a02251cd7a0e7266",
"namespace_ufe_1_1_global_selection.html#a634fa9d70d5cf0de940542075a4a4ecf",
"struct_ufe_1_1_light_1_1_cone_props.html#a86a269bcc25a529422847c17d22eb39f",
"types_8h.html#a5e09cc4c8daa300c5098863c155b235a"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';