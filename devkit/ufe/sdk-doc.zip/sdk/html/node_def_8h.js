var node_def_8h =
[
    [ "Ufe::NodeDef", "class_ufe_1_1_node_def.html", "class_ufe_1_1_node_def" ],
    [ "ConstAttributeDefs", "node_def_8h.html#abeca13a0b384a544d9610bd7740c78b4", null ],
    [ "NodeDefs", "node_def_8h.html#ac728461a7b747cc90a7ef3602cb0c7e3", null ]
];