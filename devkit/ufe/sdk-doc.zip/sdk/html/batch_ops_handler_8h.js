var batch_ops_handler_8h =
[
    [ "Ufe::BatchOpsHandler", "class_ufe_1_1_batch_ops_handler.html", "class_ufe_1_1_batch_ops_handler" ]
];