var dir_087dfbef1e2614e45041cef31a58dc54 =
[
    [ "peptide", "dir_3c560d804369aba548a075c8a3d78ce9.html", "dir_3c560d804369aba548a075c8a3d78ce9" ],
    [ "ufe", "dir_86cb96196457accb7e93ca1e941f4d66.html", "dir_86cb96196457accb7e93ca1e941f4d66" ]
];