var hierarchy =
[
    [ "Ufe::Light::AreaInterface", "class_ufe_1_1_light_1_1_area_interface.html", null ],
    [ "Ufe::AttributeDef", "class_ufe_1_1_attribute_def.html", null ],
    [ "Ufe::AttributeInfo", "class_ufe_1_1_attribute_info.html", null ],
    [ "Ufe::Attributes", "class_ufe_1_1_attributes.html", null ],
    [ "Ufe::AttributesHandler", "class_ufe_1_1_attributes_handler.html", null ],
    [ "Ufe::BatchOpsHandler", "class_ufe_1_1_batch_ops_handler.html", [
      [ "Ufe::CodeWrapperHandler", "class_ufe_1_1_code_wrapper_handler.html", null ]
    ] ],
    [ "Ufe::BBox3d", "struct_ufe_1_1_b_box3d.html", null ],
    [ "Ufe::Camera", "class_ufe_1_1_camera.html", null ],
    [ "Ufe::CameraHandler", "class_ufe_1_1_camera_handler.html", null ],
    [ "Ufe::CellInfo", "struct_ufe_1_1_cell_info.html", null ],
    [ "Ufe::ChildFilterFlag", "struct_ufe_1_1_child_filter_flag.html", null ],
    [ "Ufe::ClipboardHandler", "class_ufe_1_1_clipboard_handler.html", null ],
    [ "Ufe::CodeWrapper", "class_ufe_1_1_code_wrapper.html", null ],
    [ "Ufe::CodeWrapperContainer", "class_ufe_1_1_code_wrapper_container.html", null ],
    [ "Ufe::CodeWrapperContext", "class_ufe_1_1_code_wrapper_context.html", null ],
    [ "Ufe::Light::ConeInterface", "class_ufe_1_1_light_1_1_cone_interface.html", null ],
    [ "Ufe::Light::ConeProps", "struct_ufe_1_1_light_1_1_cone_props.html", null ],
    [ "Ufe::Connection", "class_ufe_1_1_connection.html", null ],
    [ "Ufe::ConnectionHandler", "class_ufe_1_1_connection_handler.html", null ],
    [ "Ufe::Connections", "class_ufe_1_1_connections.html", null ],
    [ "Ufe::ContextItem", "struct_ufe_1_1_context_item.html", null ],
    [ "Ufe::ContextOps", "class_ufe_1_1_context_ops.html", null ],
    [ "Ufe::ContextOpsHandler", "class_ufe_1_1_context_ops_handler.html", null ],
    [ "Ufe::Light_v5_5::CylinderInterface", "class_ufe_1_1_light__v5__5_1_1_cylinder_interface.html", null ],
    [ "Ufe::Light::DirectionalInterface", "class_ufe_1_1_light_1_1_directional_interface.html", null ],
    [ "Ufe::Light_v5_5::DiskInterface", "class_ufe_1_1_light__v5__5_1_1_disk_interface.html", null ],
    [ "Ufe::Light_v5_5::DomeInterface", "class_ufe_1_1_light__v5__5_1_1_dome_interface.html", null ],
    [ "Ufe::Duplicate", "struct_ufe_1_1_duplicate.html", null ],
    [ "Ufe::EditTransform3dHint", "class_ufe_1_1_edit_transform3d_hint.html", null ],
    [ "std::enable_shared_from_this", null, [
      [ "Ufe::Attribute", "class_ufe_1_1_attribute.html", [
        [ "Ufe::AttributeEnumString", "class_ufe_1_1_attribute_enum_string.html", null ],
        [ "Ufe::AttributeFilename", "class_ufe_1_1_attribute_filename.html", null ],
        [ "Ufe::AttributeGeneric", "class_ufe_1_1_attribute_generic.html", null ],
        [ "Ufe::TypedAttribute< T >", "class_ufe_1_1_typed_attribute.html", null ]
      ] ],
      [ "Ufe::TrieNode< T >", "class_ufe_1_1_trie_node.html", null ]
    ] ],
    [ "Ufe::HandlerInterface", "class_ufe_1_1_handler_interface.html", null ],
    [ "Ufe::RunTimeMgr::Handlers", "struct_ufe_1_1_run_time_mgr_1_1_handlers.html", null ],
    [ "std::hash< Ufe::PathComponent >", "structstd_1_1hash_3_01_ufe_1_1_path_component_01_4.html", null ],
    [ "std::hash< Ufe_v5 ::Path >", "structstd_1_1hash_3_01_ufe__v5_01_1_1_path_01_4.html", null ],
    [ "Ufe::Hierarchy", "class_ufe_1_1_hierarchy.html", null ],
    [ "Ufe::HierarchyHandler", "class_ufe_1_1_hierarchy_handler.html", null ],
    [ "Ufe::UIInfoHandler::Icon", "struct_ufe_1_1_u_i_info_handler_1_1_icon.html", null ],
    [ "std::invalid_argument", null, [
      [ "Ufe::EmptyClipboardSelection", "class_ufe_1_1_empty_clipboard_selection.html", null ],
      [ "Ufe::InvalidValueGet", "class_ufe_1_1_invalid_value_get.html", null ]
    ] ],
    [ "Ufe::Light", "class_ufe_1_1_light.html", [
      [ "Ufe::Light_v5_5", "class_ufe_1_1_light__v5__5.html", null ]
    ] ],
    [ "Ufe::LightHandler", "class_ufe_1_1_light_handler.html", null ],
    [ "Ufe::Material", "class_ufe_1_1_material.html", null ],
    [ "Ufe::MaterialHandler", "class_ufe_1_1_material_handler.html", null ],
    [ "Ufe::NodeDef", "class_ufe_1_1_node_def.html", null ],
    [ "Ufe::NodeDefHandler", "class_ufe_1_1_node_def_handler.html", null ],
    [ "Ufe::Notification", "class_ufe_1_1_notification.html", [
      [ "Ufe::AttributeChanged", "class_ufe_1_1_attribute_changed.html", [
        [ "Ufe::AttributeAdded", "class_ufe_1_1_attribute_added.html", null ],
        [ "Ufe::AttributeConnectionChanged", "class_ufe_1_1_attribute_connection_changed.html", null ],
        [ "Ufe::AttributeMetadataChanged", "class_ufe_1_1_attribute_metadata_changed.html", null ],
        [ "Ufe::AttributeRemoved", "class_ufe_1_1_attribute_removed.html", null ],
        [ "Ufe::AttributeValueChanged", "class_ufe_1_1_attribute_value_changed.html", null ]
      ] ],
      [ "Ufe::CameraChanged", "class_ufe_1_1_camera_changed.html", null ],
      [ "Ufe::LightChanged", "class_ufe_1_1_light_changed.html", null ],
      [ "Ufe::SceneChanged", "class_ufe_1_1_scene_changed.html", [
        [ "Ufe::ObjectAdd", "class_ufe_1_1_object_add.html", null ],
        [ "Ufe::ObjectDelete", "class_ufe_1_1_object_delete.html", [
          [ "Ufe::ObjectDestroyed", "class_ufe_1_1_object_destroyed.html", null ],
          [ "Ufe::ObjectPostDelete", "class_ufe_1_1_object_post_delete.html", null ],
          [ "Ufe::ObjectPreDelete", "class_ufe_1_1_object_pre_delete.html", null ]
        ] ],
        [ "Ufe::ObjectPathChange", "class_ufe_1_1_object_path_change.html", [
          [ "Ufe::ObjectPathAdd", "class_ufe_1_1_object_path_add.html", null ],
          [ "Ufe::ObjectPathRemove", "class_ufe_1_1_object_path_remove.html", null ],
          [ "Ufe::ObjectRename", "class_ufe_1_1_object_rename.html", null ],
          [ "Ufe::ObjectReparent", "class_ufe_1_1_object_reparent.html", null ]
        ] ],
        [ "Ufe::SceneCompositeNotification", "class_ufe_1_1_scene_composite_notification.html", null ],
        [ "Ufe::SubtreeInvalidate", "class_ufe_1_1_subtree_invalidate.html", null ]
      ] ],
      [ "Ufe::SelectionChanged", "class_ufe_1_1_selection_changed.html", [
        [ "Ufe::SelectionCleared", "class_ufe_1_1_selection_cleared.html", null ],
        [ "Ufe::SelectionCompositeNotification", "class_ufe_1_1_selection_composite_notification.html", null ],
        [ "Ufe::SelectionItemAppended", "class_ufe_1_1_selection_item_appended.html", null ],
        [ "Ufe::SelectionItemInserted", "class_ufe_1_1_selection_item_inserted.html", null ],
        [ "Ufe::SelectionItemRemoved", "class_ufe_1_1_selection_item_removed.html", null ],
        [ "Ufe::SelectionReplaced", "class_ufe_1_1_selection_replaced.html", null ]
      ] ],
      [ "Ufe::Transform3dChanged", "class_ufe_1_1_transform3d_changed.html", null ],
      [ "Ufe::VisibilityChanged", "class_ufe_1_1_visibility_changed.html", null ]
    ] ],
    [ "Ufe::NotificationGuard", "class_ufe_1_1_notification_guard.html", null ],
    [ "Ufe::Object3d", "class_ufe_1_1_object3d.html", null ],
    [ "Ufe::Object3dHandler", "class_ufe_1_1_object3d_handler.html", null ],
    [ "Ufe::Observer", "class_ufe_1_1_observer.html", null ],
    [ "Ufe::SceneCompositeNotification::Op", "struct_ufe_1_1_scene_composite_notification_1_1_op.html", null ],
    [ "Ufe::SelectionCompositeNotification::Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html", null ],
    [ "std::out_of_range", null, [
      [ "Ufe::InvalidOperationOnPath", "class_ufe_1_1_invalid_operation_on_path.html", null ],
      [ "Ufe::InvalidOperationOnPathSegment", "class_ufe_1_1_invalid_operation_on_path_segment.html", null ],
      [ "Ufe::InvalidPathComponentSeparator", "class_ufe_1_1_invalid_path_component_separator.html", null ],
      [ "Ufe::InvalidRunTimeId", "class_ufe_1_1_invalid_run_time_id.html", null ]
    ] ],
    [ "Ufe::PasteClipboardCommand::PasteInfo", "struct_ufe_1_1_paste_clipboard_command_1_1_paste_info.html", null ],
    [ "Ufe::Path", "class_ufe_1_1_path.html", null ],
    [ "Ufe::PathComponent", "class_ufe_1_1_path_component.html", null ],
    [ "Ufe::PathMappingHandler", "class_ufe_1_1_path_mapping_handler.html", null ],
    [ "Ufe::PathSegment", "class_ufe_1_1_path_segment.html", null ],
    [ "Ufe::Rename", "struct_ufe_1_1_rename.html", null ],
    [ "std::runtime_error", null, [
      [ "Ufe::EmptyClipboardOperation", "class_ufe_1_1_empty_clipboard_operation.html", null ],
      [ "Ufe::EmptyPathSegment", "class_ufe_1_1_empty_path_segment.html", null ],
      [ "Ufe::InvalidPath", "class_ufe_1_1_invalid_path.html", null ],
      [ "Ufe::InvalidRunTimeName", "class_ufe_1_1_invalid_run_time_name.html", null ],
      [ "Ufe::NoClipboardHandler", "class_ufe_1_1_no_clipboard_handler.html", null ]
    ] ],
    [ "Ufe::RunTimeMgr", "class_ufe_1_1_run_time_mgr.html", null ],
    [ "Ufe::SceneItem", "class_ufe_1_1_scene_item.html", null ],
    [ "Ufe::SceneItemOps", "class_ufe_1_1_scene_item_ops.html", null ],
    [ "Ufe::SceneItemOpsHandler", "class_ufe_1_1_scene_item_ops_handler.html", null ],
    [ "Ufe::SceneSegmentHandler", "class_ufe_1_1_scene_segment_handler.html", null ],
    [ "Ufe::Selection", "class_ufe_1_1_selection.html", [
      [ "Ufe::ObservableSelection", "class_ufe_1_1_observable_selection.html", null ]
    ] ],
    [ "Ufe::Light::SphereInterface", "class_ufe_1_1_light_1_1_sphere_interface.html", null ],
    [ "Ufe::Light::SphereProps", "struct_ufe_1_1_light_1_1_sphere_props.html", null ],
    [ "Ufe::Subject", "class_ufe_1_1_subject.html", [
      [ "Ufe::ObservableSelection", "class_ufe_1_1_observable_selection.html", null ],
      [ "Ufe::PathSubject", "class_ufe_1_1_path_subject.html", [
        [ "Ufe::Transform3dPathSubject", "class_ufe_1_1_transform3d_path_subject.html", null ]
      ] ],
      [ "Ufe::Scene", "class_ufe_1_1_scene.html", null ]
    ] ],
    [ "Ufe::Transform3dHandler", "class_ufe_1_1_transform3d_handler.html", null ],
    [ "Ufe::Transform3dRead", "class_ufe_1_1_transform3d_read.html", [
      [ "Ufe::Transform3d", "class_ufe_1_1_transform3d.html", null ]
    ] ],
    [ "Ufe::Trie< T >", "class_ufe_1_1_trie.html", null ],
    [ "Ufe::TypedColorN< T, SZ >", "struct_ufe_1_1_typed_color_n.html", null ],
    [ "Ufe::TypedColorN< float, 3 >", "struct_ufe_1_1_typed_color_n.html", null ],
    [ "Ufe::TypedSquareMatrixN< T, SZ >", "struct_ufe_1_1_typed_square_matrix_n.html", null ],
    [ "Ufe::TypedVectorN< T, SZ >", "struct_ufe_1_1_typed_vector_n.html", null ],
    [ "Ufe::TypedVectorN< double, 3 >", "struct_ufe_1_1_typed_vector_n.html", null ],
    [ "Ufe::UIInfoHandler", "class_ufe_1_1_u_i_info_handler.html", null ],
    [ "Ufe::UINodeGraphNode", "class_ufe_1_1_u_i_node_graph_node.html", null ],
    [ "Ufe::UINodeGraphNodeHandler", "class_ufe_1_1_u_i_node_graph_node_handler.html", null ],
    [ "Ufe::UndoableCommand", "class_ufe_1_1_undoable_command.html", [
      [ "Ufe::AttributeUndoableCommand", "class_ufe_1_1_attribute_undoable_command.html", null ],
      [ "Ufe::BaseUndoableCommand", "class_ufe_1_1_base_undoable_command.html", [
        [ "Ufe::SetValue2UndoableCommand< VALUE_TYPE >", "class_ufe_1_1_set_value2_undoable_command.html", null ],
        [ "Ufe::SetValue3UndoableCommand< VALUE_TYPE >", "class_ufe_1_1_set_value3_undoable_command.html", null ],
        [ "Ufe::SetValue4UndoableCommand< VALUE_TYPE >", "class_ufe_1_1_set_value4_undoable_command.html", null ],
        [ "Ufe::SetValueUndoableCommand< VALUE_TYPE >", "class_ufe_1_1_set_value_undoable_command.html", null ]
      ] ],
      [ "Ufe::CompositeUndoableCommand", "class_ufe_1_1_composite_undoable_command.html", [
        [ "Ufe::BatchCompositeCommand", "class_ufe_1_1_batch_composite_command.html", null ]
      ] ],
      [ "Ufe::ConnectionResultUndoableCommand", "class_ufe_1_1_connection_result_undoable_command.html", null ],
      [ "Ufe::InsertChildCommand", "class_ufe_1_1_insert_child_command.html", null ],
      [ "Ufe::PasteClipboardCommand", "class_ufe_1_1_paste_clipboard_command.html", null ],
      [ "Ufe::SceneItemResultUndoableCommand", "class_ufe_1_1_scene_item_result_undoable_command.html", null ],
      [ "Ufe::SelectionAppendItem", "class_ufe_1_1_selection_append_item.html", null ],
      [ "Ufe::SelectionClear", "class_ufe_1_1_selection_clear.html", null ],
      [ "Ufe::SelectionRemoveItem", "class_ufe_1_1_selection_remove_item.html", null ],
      [ "Ufe::SelectionReplaceWith", "class_ufe_1_1_selection_replace_with.html", null ],
      [ "Ufe::SelectionUndoableCommand", "class_ufe_1_1_selection_undoable_command.html", null ]
    ] ],
    [ "Ufe::UndoableCommandGuard", "class_ufe_1_1_undoable_command_guard.html", null ],
    [ "Ufe::UndoableCommandMgr", "class_ufe_1_1_undoable_command_mgr.html", null ],
    [ "Ufe::Value", "class_ufe_1_1_value.html", null ],
    [ "Peptide::VersionFormat< VersionTrait >", "class_peptide_1_1_version_format.html", null ],
    [ "Peptide::VersionInfo", "class_peptide_1_1_version_info.html", null ],
    [ "Ufe::VersionInfo", "class_ufe_1_1_version_info.html", null ],
    [ "Ufe::Light_v5_5::VolumeProps", "struct_ufe_1_1_light__v5__5_1_1_volume_props.html", null ]
];