var class_ufe_1_1_connection =
[
    [ "Ptr", "class_ufe_1_1_connection.html#a818b29af8b40cc093ccdd74bb4242465", null ],
    [ "Connection", "class_ufe_1_1_connection.html#ac9bf63b938e4fa8692d2ba5578f5137e", null ],
    [ "~Connection", "class_ufe_1_1_connection.html#a40bade746c630275636815a31effb2e7", null ],
    [ "Connection", "class_ufe_1_1_connection.html#a9f7855086bc253034284c0726451ba28", null ],
    [ "Connection", "class_ufe_1_1_connection.html#ae712208166f57073ef09932ad08b8b48", null ],
    [ "dst", "class_ufe_1_1_connection.html#a2d1fd1949a7f086d323f4836a6536a5e", null ],
    [ "operator=", "class_ufe_1_1_connection.html#ab953e95a49648b140a37f0ae39ae90b5", null ],
    [ "operator=", "class_ufe_1_1_connection.html#afc420df26110a1a8fa15787941fcd359", null ],
    [ "src", "class_ufe_1_1_connection.html#ad68d2a1645d437ac64948f46c30b20bd", null ],
    [ "fDst", "class_ufe_1_1_connection.html#ade646c698ea19e6f3b4b8780bb32f403", null ],
    [ "fSrc", "class_ufe_1_1_connection.html#a6046e4964d09ddc2899971563b1b7a88", null ]
];